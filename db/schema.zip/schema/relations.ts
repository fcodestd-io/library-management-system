import { relations } from "drizzle-orm";
import { loans } from "./loans";
import { fines } from "./fines";
import { payments } from "./payments";
import { bookCopies } from "./book-copies";
import { members } from "./members";
import { users } from "./users";

// ==========================================
// 1. RELASI TABEL LOANS
// ==========================================
export const loansRelations = relations(loans, ({ one, many }) => ({
  // Peminjaman milik 1 Anggota (Member)
  member: one(members, {
    fields: [loans.memberId],
    references: [members.id],
  }),

  // Peminjaman terikat pada 1 Copy/Eksemplar Buku
  bookCopy: one(bookCopies, {
    fields: [loans.bookCopyId],
    references: [bookCopies.id],
  }),

  // Petugas yang memproses peminjaman awal
  processedByStaff: one(users, {
    fields: [loans.processedBy],
    references: [users.id],
    relationName: "loan_processor",
  }),

  // Petugas yang menerima pengembalian buku (returnedProcessedBy)
  returnedByStaff: one(users, {
    fields: [loans.returnedProcessedBy],
    references: [users.id],
    relationName: "return_processor",
  }),

  // 1 Peminjaman bisa memiliki banyak Denda (misal: denda terlambat & denda rusak)
  fines: many(fines),

  // 1 Peminjaman bisa memiliki banyak transaksi Pembayaran (sewa & denda)
  payments: many(payments),
}));

// ==========================================
// 2. RELASI TABEL FINES
// ==========================================
export const finesRelations = relations(fines, ({ one, many }) => ({
  // 1 Denda berasal dari 1 Peminjaman (Loan)
  loan: one(loans, {
    fields: [fines.loanId],
    references: [loans.id],
  }),

  // 1 Denda bisa memiliki banyak riwayat Pembayaran (misal: partial payment/cicilan)
  payments: many(payments),
}));

// ==========================================
// 3. RELASI TABEL PAYMENTS
// ==========================================
export const paymentsRelations = relations(payments, ({ one }) => ({
  // Pembayaran dilakukan oleh 1 Anggota
  member: one(members, {
    fields: [payments.memberId],
    references: [members.id],
  }),

  // Pembayaran terikat pada 1 Peminjaman (opsional)
  loan: one(loans, {
    fields: [payments.loanId],
    references: [loans.id],
  }),

  // Pembayaran terikat pada 1 Denda (opsional)
  fine: one(fines, {
    fields: [payments.fineId],
    references: [fines.id],
  }),

  // Petugas kasir yang memproses transaksi pembayaran
  processor: one(users, {
    fields: [payments.processedBy],
    references: [users.id],
  }),
}));

// ==========================================
// 4. RELASI TABEL USERS (Petugas / Owner)
// ==========================================
export const usersRelations = relations(users, ({ many }) => ({
  // User memproses banyak peminjaman awal
  processedLoans: many(loans, { relationName: "loan_processor" }),

  // User memproses banyak penerimaan pengembalian
  processedReturns: many(loans, { relationName: "return_processor" }),

  // User memproses banyak transaksi pembayaran kasir
  processedPayments: many(payments),
}));

// ==========================================
// 5. RELASI TABEL MEMBERS
// ==========================================
export const membersRelations = relations(members, ({ many }) => ({
  loans: many(loans),
  payments: many(payments),
}));

// ==========================================
// 6. RELASI TABEL BOOK COPIES
// ==========================================
export const bookCopiesRelations = relations(bookCopies, ({ many }) => ({
  loans: many(loans),
}));
